# DingTalk Memory 隔离实施计划

> 状态：connector 源码与 OpenClaw `2026.7.1-2` 版本绑定 patch 已实现并在临时副本验证；尚未安装或在 Gateway 生效。

## 1. 目标与边界

目标：

- `memory_search` 保持 OpenClaw 原有的全局检索和 `corpus` 行为；
- 在检索完成后、结果交给模型前，由 connector 通过 `api.registerAgentToolResultMiddleware` 过滤其他用户或群聊的私有 Memory；
- OpenClaw 仅做最小 `sessionKey` 上下文透传补丁，不修改 `memory_search` 检索、retry、合并或结果构造逻辑；
- `memory_read`/`memory_get`/普通 `read` 不走结果补丁，直接由 connector `tool_guard` 限定读取范围；
- 通过独立 session 和 session visibility 防止会话记录串用。

本期不实现：

- 查询前的 path filter 或完整召回率保证；
- QMD 多 collection 改造；
- `exec`、MCP、自定义插件和宿主文件系统的统一沙箱；
- `write`、`edit`、`apply_patch` 的完整写权限矩阵。

实施前置门槛：

- 先冻结并在 result middleware、Tool Guard、bootstrap、测试中使用同一访问矩阵；本计划将根 `MEMORY.md` 视为公共 Memory，允许读取；
- 先确认实际 OpenClaw 的 `registerAgentToolResultMiddleware` 契约，并验证 `openclaw` runtime 将可信 `sessionKey` 传给 handler；
- 先确认 OpenClaw 当前 `before_tool_call` 事件的参数和 block/rewrite 返回契约，再实现 hook；
- 读取隔离与写入重定向分开发布。本期不得因启用 Tool Guard 改写 `write`/`edit` 或系统 compaction 写入。

## 2. 允许范围

路径先做词法校验，再规范化为 workspace-relative POSIX 路径：拒绝绝对路径、任何 `..` 段、NUL、反斜杠、编码后逃逸和前缀误匹配；随后校验真实路径未通过 symlink 逃出 workspace。

对 DingTalk 会话，Memory 结果只允许：

- 根 `MEMORY.md`；
- `memory/` 下的公共文件；
- 当前私聊用户的 `memory/users/<A>/**`；
- 当前群共享的 `memory/groups/<G>/**`，但拒绝 `memory/groups/<G>/users/**`；
- `group_sender` 模式下的 `memory/groups/<G>/users/<A>/**`。

其他用户、其他群聊及其他私有子树一律拒绝。解析器必须返回三态：`non_dingtalk`、`valid`、`malformed_dingtalk`；后者 fail-closed，不能退化为非 DingTalk 放行。scope 使用可信的 session context/已生效配置解析，不从未经验证的字符串片段猜测 account 或 `group_sender`。原始 ID 不得先整体小写，路径编码还必须避免不同 ID 发生目录碰撞；非 DingTalk session 保持原行为。

## 3. 调用链

```text
DingTalk message
  -> 独立 sessionKey
  -> memory_search（保持全局搜索/corpus）
  -> OpenClaw manager 完成检索及 retry
  -> memory_search 返回完整 jsonResult
  -> connector AgentToolResultMiddleware
  -> 按 ctx.sessionKey 过滤 result.details.results
  -> 同步重建 result.content JSON
  -> 模型只看到公共 Memory + 当前 scope
```

直接读取：

```text
memory_read / memory_get / read
  -> connector tool_guard
  -> scope classifier
  -> allow 或 block
```

## 4. OpenClaw 最小 Session Context Patch

### 4.1 目的与边界

当前已检查的 OpenClaw `2026.7.1-2` 中，`createAgentToolResultMiddlewareRunner(ctx, handlers?)` 已支持：

```text
runtime
agentId
sessionId
sessionKey
runId
```

但普通 `openclaw` runtime 当前只传入 `runtime: "openclaw"`，导致 connector middleware 无法判断本次搜索属于哪个用户或群。本 patch 只把 agent attempt 已持有的可信 `agentId`、`sessionId`、`sessionKey`、`runId` 经 `buildEmbeddedExtensionFactories()` 和 `buildAgentToolResultMiddlewareFactory()` 传给 runner。

不得从模型参数、`memory_search.args`、全局变量或未经验证的字符串字段补造 scope；缺少可信 `sessionKey` 时不能执行精确私有 scope 放行。

### 4.2 版本与定位

实施前确认 Gateway 实际加载的 OpenClaw：

```bash
command -v openclaw
readlink -f "$(command -v openclaw)"
openclaw --version
openclaw gateway status
```

`readlink` 得到的实际安装根目录必须与 Gateway 正在加载的 dist 一致；禁止仅凭 `npm root -g` 推断目标。版本不匹配、目标文件不唯一或任一锚点缺失时立即失败，不得仅 warning 后继续。

patch 必须按实际版本单独存放，例如：

```text
openclaw-patch/<actual-version>/agent-tool-result-session-context/
├── README.md
├── apply.sh
├── patch.diff
└── verify-agent-tool-result-session-context.mjs
```

`apply.sh` 在 `dist/` 中唯一定位包含以下锚点的 bundle，否则立即失败：

- `buildAgentToolResultMiddlewareFactory`；
- `buildEmbeddedExtensionFactories`；
- `createAgentToolResultMiddlewareRunner({ runtime: "openclaw" })` 或等价稳定上下文；
- 正常 agent attempt 中同时存在 `params.sessionKey`、`params.sessionId`、`params.runId` 和可信 agent id 的调用点。

补丁后的 runner 创建语义：

```js
createAgentToolResultMiddlewareRunner({
  runtime: "openclaw",
  agentId,
  sessionId,
  sessionKey,
  runId,
});
```

正常 agent attempt 和具备会话上下文的 compaction 路径都要透传其已有字段；不得改变 Codex runtime 原有行为。

### 4.3 脚本要求

`apply.sh` 必须版本绑定、检查锚点、生成备份、幂等执行、运行语法检查和 verifier；任一步失败返回非零，禁止自动重启 Gateway。版本不匹配不得仅 warning 后继续。

verifier 至少证明两个不同并发 session 的 middleware handler 分别收到各自 `sessionKey`，并验证 `agentId/sessionId/runId` 未串用。若未来 OpenClaw 版本已原生正确透传，可取消此 patch，但必须先通过同一 verifier。

## 5. Connector Result Middleware

### 5.1 文件职责

过滤逻辑全部写在 connector 的 `src/memory-scope/`，不写入 OpenClaw `memory_search` bundle：

```text
src/memory-scope/
├── session-scope.ts          # sessionKey -> 三态 DingTalk scope
├── path-classifier.ts        # 共享路径规范化与 allow/deny
├── search-result-filter.ts   # 纯函数过滤 memory_search payload
├── result-middleware.ts      # 注册 AgentToolResultMiddleware
├── tool-guard.ts             # 直接读取执行前阻断
└── register.ts               # 统一注册入口
```

若复用现有 `paths.ts`，必须把路径权限分类与文件创建、写路径重定向职责分开，避免本期意外启用写入行为。

### 5.2 Scope 与共享 Classifier

新增或重构纯函数：

```text
classifyDingtalkSession(sessionKey)
resolveDingtalkMemoryScope(sessionKey)
normalizeMemoryHitPath(path)
isMemoryPathAllowed(path, scope)
filterMemorySearchPayload(payload, scope)
```

`classifyDingtalkSession()` 返回 `non_dingtalk`、`valid`、`malformed_dingtalk` 三态。middleware 与 Tool Guard 必须复用相同 classifier；不得接受模型传入的 `scopeDir`、`allowedPaths` 或权限标志。

### 5.3 Middleware 注册与结果重建

在 `registerMemoryScope()` 中按 `memoryScope.enabled` 注册：

```ts
api.registerAgentToolResultMiddleware(handler, {
  runtimes: ["openclaw"],
});
```

handler 仅处理 `event.toolName === "memory_search"`：

- `non_dingtalk`：不修改结果；
- `malformed_dingtalk` 或缺少可信上下文：返回空结果或安全错误，禁止回退原始结果；
- `valid`：解析并校验 `event.result`，按 `ctx.sessionKey` 得到的 scope 过滤 `results`；
- 结果格式无法验证时 fail-closed，不把原始 JSON 交给 DingTalk 模型。

OpenClaw `jsonResult()` 同时把 payload 放在 `result.details` 和 `result.content[0].text`。middleware 必须以过滤后的同一个 payload 同步重建两者，并相应更新 `debug.hits` 等派生计数；只修改 `details.results` 不构成隔离。

对 `corpus=all` 按每条 hit 的 `corpus/source` 分流：`memory` 使用路径 classifier；`sessions` 必须继续满足 OpenClaw session visibility，无法确认时拒绝；`wiki` 只在明确属于公共 supplement 时允许；未知 corpus 对 DingTalk fail-closed。

不通过改写或禁止 `corpus` 实现隔离。`memory`、`sessions`、`wiki`、`all` 等 corpus 均按原行为检索，但其返回候选都必须经过过滤；无法归一化为允许路径的结果不交给 DingTalk 模型。

### 5.4 Manifest Contract

`openclaw.plugin.json` 必须声明：

```json
{
  "contracts": {
    "agentToolResultMiddleware": ["openclaw"]
  }
}
```

installed plugin 还必须在生产配置中显式启用；未声明 contract、未显式启用或注册 diagnostic 非空均视为未生效。

## 6. Connector Tool Guard

在确认当前 OpenClaw hook 契约后，在 `registerMemoryScope()` 注册 `before_tool_call`，仅处理 DingTalk session 的直接读取工具：

- `memory_read`/`memory_get`：仅允许缺省 corpus 或 `corpus=memory`，并按同一 classifier 检查路径；
- 普通 `read`：Memory 树内按 classifier 检查，树外维持现有工具策略；
- 绝对路径、`..`、workspace 逃逸、symlink 逃逸、其他私有 scope 和 malformed DingTalk session 直接 block；
- 不改写、不限制 `memory_search` 的 `corpus`，不接受模型传入的 `allowedPaths` 或 scope 权限参数；
- 非 DingTalk session 不改变原行为；本期不注册或处理 `write`、`edit`、`apply_patch` 的重写逻辑。

若当前 OpenClaw 没有独立 `memory_read` 工具，则按实际暴露的 `memory_get` 接入同一 guard。

Result Middleware 与 Tool Guard 使用同一组表驱动 classifier 用例，避免规则分叉；hook 测试必须验证实际 event/context 字段、block 返回值和重复注册行为。

## 7. 会话配置

合并配置前先检查生产配置和 schema，不覆盖已有字段。目标配置语义：

```json5
{
  session: { dmScope: "per-account-channel-peer" },
  tools: { sessions: { visibility: "self" } },
  agents: {
    defaults: { memorySearch: { experimental: { sessionMemory: false } } },
  },
  channels: {
    "dingtalk-connector": {
      separateSessionByConversation: true,
      sharedMemoryAcrossConversations: false,
      groupSessionScope: "group",
      memoryScope: { enabled: true },
    },
  },
}
```

`session.dmScope`、`tools.sessions.visibility` 和 `memorySearch.experimental.sessionMemory` 需先用当前 Gateway schema/config check 确认支持及实际生效位置；connector schema 只负责 `channels.dingtalk-connector.memoryScope` 等自身字段，不得假定上述顶层字段可直接写入。

不得新增 `sources: ["memory"]` 等配置来缩小 `memory_search` 的全局检索范围。若群成员需要互相隔离，将 `groupSessionScope` 改为 `group_sender`。

## 8. 测试计划

### 8.1 Classifier

覆盖公共 Memory、私聊 A、群 G、group_sender G/A 的允许/拒绝矩阵，并验证：

- `users/A` 不匹配 `users/AB`；
- 群共享拒绝 `groups/G/users/**`；
- 绝对路径、`..`、反斜杠、编码边界被拒绝；
- symlink 逃逸、大小写 ID、碰撞 ID、单账号、多账号和 malformed session；
- 非 DingTalk session 不受影响。

### 8.2 Session Context Patch 与 Middleware

- verifier 证明普通 `openclaw` runtime handler 收到正确的 `agentId/sessionId/sessionKey/runId`；
- A/B、G/H 和 `group_sender` 并发运行不串 scope；
- manifest contract 缺失、插件未显式启用和 runtime 不匹配时测试必须失败并暴露 diagnostic；
- middleware 异常、非法 payload、缺少 `sessionKey` 和 malformed DingTalk session 均 fail-closed；
- `result.details` 与 `result.content[0].text` 解析后完全一致。

### 8.3 Search 返回值

使用 `PUBLIC_MARKER`、`USER_A_SECRET`、`USER_B_SECRET`、`GROUP_G_SECRET` 等唯一标记，验证：

- A/B/G/group_sender 只能看到公共内容和自身允许 scope；
- 首次搜索、retry、空结果 retry 和 memory/supplement 合并后的最终 results 都经过 middleware 过滤；
- `corpus=memory/sessions/wiki/all` 不绕过返回值过滤；
- 被拒绝 marker 不出现在模型可见的 citation、最终 JSON、`content` 或 `details`；
- malformed DingTalk session 不回退全局结果；
- 非 DingTalk 结果保持基线。

### 8.4 Tool Guard 与临时副本

- 直接读取的公共路径、当前 scope 允许，其他私有路径拒绝；
- scope 解析失败拒绝；
- 根 `MEMORY.md`、公共 `memory/**`、当前 scope 和其他私有 scope 的最终矩阵与第 2 节一致；
- hook 契约、重复注册和非 DingTalk bypass 均有测试；
- 在 `/tmp` OpenClaw 副本验证 session context patch 的首次应用、重复应用、版本/锚点不匹配、语法和 verifier；
- 使用安装后的 connector 验证真实 middleware 注册和模型可见 JSON；
- 未 patch 基线应能复现跨 scope 命中，避免测试假阳性。

### 8.5 生产 smoke test

使用测试账号和测试群验证 A/B、G/H、group_sender 的正向与负向唯一字符串；检查 Gateway、memory manager 和 connector hook 日志，并做一次非 DingTalk 回归。

## 9. 已知限制与演进

当前是“全局 Top-N 后过滤”。其他 scope 可能占满候选，造成合法结果漏召回，但过滤后的结果不泄漏。

Result Middleware 在 `memory_search` 完全执行后运行，因此无法阻止未过滤 hit 被工具内部 `queueShortTermRecallTracking()` 使用。当前验收只承诺模型可见结果隔离；若 tracking 也必须隔离，需要后续在 memory-core 内增加可信 scope 过滤，不能声称 middleware 已覆盖。

可选缓解：提高内部候选数，过滤后再截断，并设置上限。长期方案是在 manager 的向量、FTS/BM25、LIKE 和 keyword 分支中，在排序和 `LIMIT` 前传入 `pathScope`。

## 10. 发布与回滚

发布顺序：

1. 确认实际 OpenClaw 加载路径、版本、backend、middleware API 和 manifest contract；
2. 冻结访问矩阵并完成 classifier、路径/symlink 校验测试；
3. 完成最小 session context patch verifier，并证明 handler 收到正确 `sessionKey`；
4. 完成 connector result middleware、模型可见 JSON 和未 patch 基线测试；
5. 完成只读 Tool Guard hook 测试；
6. 备份 dist、connector 和配置，记录路径、版本、校验值；
7. 在 `/tmp` 副本首次/重复应用并验证后，再应用 patch 与 connector；
8. 安全重启 Gateway，确认 middleware 注册无 diagnostic，执行生产 smoke test 并记录证据。

出现跨 scope marker、malformed session 回退、非 DingTalk 异常、Gateway/memory-core 启动失败或 Tool Guard 误拦截时立即回滚。回滚只能恢复备份或同版本安装，DingTalk 期间应禁用 `memory_search`，不能恢复为未过滤的全局结果。

## 11. 验收标准

- [ ] 实际 Gateway 版本对应的最小 session context patch 已生成并可幂等应用，或当前版本已原生通过同一 verifier；
- [ ] 普通 `openclaw` runtime middleware 收到可信且正确的 `sessionKey`；
- [ ] connector manifest 已声明 `agentToolResultMiddleware: ["openclaw"]`，插件显式启用且无注册 diagnostic；
- [ ] `memory_search` 全局检索/corpus 行为未被改写；
- [ ] connector middleware 在模型可见前过滤所有最终 results，并同步重建 `content` 与 `details`；
- [ ] `memory_read`/`memory_get`/`read` 已由 Tool Guard 限定范围；
- [ ] 本期未改变 `write`/`edit`/`apply_patch` 行为；
- [ ] malformed DingTalk session fail-closed；
- [ ] session key、visibility 和 transcript indexing 隔离生效；
- [ ] A/B、群聊、group_sender 负向 smoke test 通过；
- [ ] 非 DingTalk 回归通过；
- [ ] 已记录安装路径、版本、备份、回滚命令，以及“Top-N 后过滤”和“内部 tracking 发生在 middleware 前”的限制。
